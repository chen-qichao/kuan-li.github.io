#is.py, 相等和is的区别
a = [1, 2, 3]
b = a#b和a是一个实体
print ( "id(a) is ", id(a), ",id(b) is ",
        id(b), ", a is b:", a is b)

c= [1, 2, 3]#c和a不同
print ( "id(a) is ", id(a), ",id(c) is ",
        id(c), ", a is c:", a is c)

d= 7#不可变类型，缓存机制，同样实体
e= 7
print ( "id(d) is ", id(d), ",id(e) is ",
        id(e), ", d is e:", d is e)
