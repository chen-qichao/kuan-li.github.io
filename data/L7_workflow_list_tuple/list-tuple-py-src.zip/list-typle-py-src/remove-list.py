l = ['huawei', 'xman', 4.56, 'xman']
print("原列表为",l)

l.remove('xman') #只删除等于xman的第一个元素
print("列表为", l)

l.remove(2) # 删除不存在的值会抛出ValueError异常
