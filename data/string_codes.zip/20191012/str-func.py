#操作函数

tmpStr1="abc123"

print("\"xyz123\"的长度为%d" % len("xyz123"))

print("hello" + str(1.23))
#print("hello" + 1.23) #Error

print(hex(425)) #16进制
print(oct(425)) #8进制
print(bin(425)) #2进制

#range表示生成
for i in range(0,12):
    print(chr(9800+i), end="")

print("")
print(ord('✔'))

