l = ['huawei', 'xman', 4.56]
print("原列表为",l)

var1=l.pop() # 不给定参数时，默认删除(弹出)最后一个元素
print("列表为", l, "弹出值为",var1)

l.pop(0)  # 删除列表第一个元素
print("列表为", l)

# 继续删除列表的值,只余１个元素，pop(0)等价于pop(-1)
l.pop()
print("列表为", l)
