#集合去重
import random #导入random库

list1 = [] #建立空列表

while True:
    num = random.randint(1,100) #在[1,100]之间取随机整数

    if num not in list1: #直接用not in判断num是否在list1中
        list1.append(num)

        if len(list1) >= 10: #取够10个退出
            break

print(list1)
