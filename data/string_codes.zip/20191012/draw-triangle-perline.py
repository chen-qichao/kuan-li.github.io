import math
import time

tmpStr=input("请输入打印三角形的行数")
lines=int(tmpStr)
max_line_width=2*lines + 1

for i in range(0,lines):
    star_len= 2*i + 1
    line_str=star_len*"*"
    print(line_str.center(max_line_width))
    time.sleep(1)
