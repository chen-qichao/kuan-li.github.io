#python多分支结构纠错1

mark = int(input("请输入取得的分数: "))

#下句等价于"if 60 <= mark and mark < 70"
if 60 <= mark < 70:
    print ("You got C Grade !!")
elif 70 <= mark < 85:
    print ("You got B Grade !!")
elif 85 < mark:
    print ("You got A Grade !!")
else:
    print ("You failed !!")

input("按回车退出")
