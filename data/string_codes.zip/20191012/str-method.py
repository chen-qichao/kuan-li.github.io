#操作函数

tmpStr = "AbCdEfGh"

print(tmpStr.lower())
print(tmpStr)
print("")

another_str=tmpStr.upper()
print(another_str)
print("")

#无参数时默认以空格区分
list1= "A,B,C".split(",")
print(list1)
print("")

#count:个数
print("a apple a day".count("a"))
print("")

print(tmpStr.replace("d","XYZ"))
print(tmpStr)
print("")

#体会副本的区别
print(tmpStr.center(20,"="))
print(tmpStr)
print("")

tmpStr1="AbCAbCAbCAb"
print(tmpStr1.strip("Ab"))
print(tmpStr1.strip("bA"))
print(tmpStr1)
print("")

print(",".join(tmpStr))
print(tmpStr)
