#获取星期字符串 
'''
         - 输入：1-7的整数，表示星期几
         - 输出：输入整数对应的星期字符串
         - 例如：输入3，输出 星期三 
        '''

weekDayStr = "星期一星期二星期三星期四星期五星期六星期日"
weekDayId = int(input("请输入星期数字(1-7)："))
pos = (weekDayId - 1 ) * 3
print(weekDayStr[pos: pos+3])

