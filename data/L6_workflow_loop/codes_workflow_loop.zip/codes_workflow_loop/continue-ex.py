#continue在while循环中的示例
n = 0 #给循环控制变量赋初值为

while n < 5: #循环，当n<5时
    n += 1 #等价于n=n+1
    if n == 3: #条件判断，如果n为３,执行continue，短路后续部分
        continue
    print (n) #如果未执行continue，打印输出n

print("while循环执行完毕")

#continue在while循环中的示例
for n in range(5): #遍历[0,5),依次取值放入n中
    n += 1
    if n== 3:
        continue
    print (n)

print("for循环执行完毕")
