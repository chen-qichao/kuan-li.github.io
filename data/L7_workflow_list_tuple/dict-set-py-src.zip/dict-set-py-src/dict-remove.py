#字典中pop,popitem用法

aDict = {'age':39, 'score': [98,97],
        'name': 'Dong','sex':'male'}

del aDict["age"] #删除指定元素
print(aDict)

#弹出指定键对应的元素, 也支持默认值，如pop("sex","male")
aDict.pop("sex")
print(aDict)

#无参数，弹出一个元素(随机)，故每次结果可能不同
aDict.popitem()
print(aDict)
