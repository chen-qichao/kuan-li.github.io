#client-area.py

import math
r1 = 12.34 #指定不同的半径
r2 = 9.08
r3 = 73.1

s1 = math.pi * r1 * r1 #面积公式s=pi * r^2
s2 = math.pi * r2 * r2 #相同的写法要调用多次
s3 = math.pi * r3 * r3

print("s1 is {:.2f}, s2 is {:.2f}, s3 is {:.2f}".format(s1,s2,s3))
