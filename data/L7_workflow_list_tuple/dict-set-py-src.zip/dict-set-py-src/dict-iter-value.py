#字典遍历

aDict = {'age':39, 'score': [98,97],
        'name': 'Dong','sex':'male'}

#values()以列表形式返回字典中的所有值
for item in aDict.values():
    print(item, end=" ")
print()

#下列用法与上面等价
#items()以列表形式将键和值二元元组tuple返回
for item in aDict.items():
    print(item[0], end=" : ")
    print(item[1], end=" , ")
print()
