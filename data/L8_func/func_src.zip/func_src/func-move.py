#func-move.py 演示函数可返回多个值
#导⼊ math 包，并允许后续代码引⽤math包⾥的sin,cos等函数
import math

def move(x, y, step, angle):
    nx = x + step * math.cos(angle)
    ny = y - step * math.sin(angle)
    return nx, ny #实际返回的是１个元组(nx,ny)

a,b = move(100, 100, 60, math.pi / 6) #隐含着元组的解包
print(a, b)
