#depack-star.py 序列解包
a, *b, c = 'PYTHON' #字符串长度较长,注意*号的效果
print(a,c)
print(b)

s = 'ABCDEFGH'
while s:
    #等价于front,s = s[0], list(s[1:])
    front, *s = s #解包，除第１个元素外，其余都赋值给s
    print(front, s)
