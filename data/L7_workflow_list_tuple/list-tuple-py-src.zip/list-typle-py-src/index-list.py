l = ['huawei', 'xman', 4.56, 2018]
print('l[0]=', l[0])
print('l[1]=', l[1])
print('l[3]=', l[3])
print('l[-1]=', l[-1])  # 倒序访问列表，-1表示最后一个

# 此行会报错，抛出IndexError异常，列表下标越界
print('l[4]=', l[4])
