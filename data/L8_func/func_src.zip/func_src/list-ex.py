#list-ex.py, 列表类型共享引用

a = [1, 2, 3]
b = a
a[0] = 0 #并未改变a的引用，只是改变了被引用对象的内部元素
print(a, "id(a) is", id(a))
#b引用的对象发生了变化，因此b的值也发生了改变
print(b, "id(b) is", id(b))
