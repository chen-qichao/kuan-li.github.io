#depack.py 序列解包
a, b, c = (1, 2, 3) #参数个数与元组长度一致
print(a,c)
[a, b, c] = [1, 2, 3] #参数个数与列表长度一致
print(a,c)
a, b, c = 'SUN' #刚好三个字符的字符串
print(a,c)
a, b, c = 'PYTHON' #字符串长度较长，会报错
print(a,c)
