#list-shallow-copy.py, 浅复制
a = [1, [4, 5, 6]]
b = a[:] # 单独创建了新的对象，并拷贝列表中的元素到新对象中

#浅拷贝，虽然a和b指向不同对象，
#但其中的元素(尤其是二级列表)指向相同的对象
print("id(a) is", id(a), "id(b) is", id(b))
print("id(a[0]) is", id(a[0]), "id(b[0]) is", id(b[0]))
print("id(a[1]) is", id(a[1]), "id(b[1]) is", id(b[1]))
