#从列表中依次取一个元素,放入循环变量item

for item in [1234,"python", 56.78]:
    print(item)
