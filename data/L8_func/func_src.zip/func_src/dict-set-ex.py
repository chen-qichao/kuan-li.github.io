#dict-set-ex
a = {1, 2, 3}
b = a.copy() #集合的复制，浅复制
print("id(a) is", id(a), ",id(b) is", id(b))

c = {1:"a", 2:"b", 3:"c"}
d = c.copy() #字典的复制，浅复制
print("id(c) is", id(c), ",id(d) is", id(d))
