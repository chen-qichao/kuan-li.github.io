#有序序列支持的函数和方法

str1="hello,python"
list1=["hello",100, 56.78]

#调用len函数, 返回字符串和列表的长度(元素个数)
print("字符串\"{}\"的长度为{}".format(str1, len(str1)))
print("列表list1的长度为{}".format(len(list1)))

#调用max函数
print("max(str1) is {}".format(max(str1)))
#无法对list1调用max或min函数,因为其中的元素(字符串和数字无法比较大小)

#调用index函数,第一次出现某个元素的位置
print("字符串\"{}\"的第一次出现字符o的位置为{}".format(str1, str1.index("o")))
print("列表list1中元素100第一次出现的位置为{}".format(list1.index(100)))

#调用count函数,出现某个元素的总次数
print("字符串\"{}\"的出现字符o的次数为{}".format(str1, str1.count("o")))
print("列表list1的元素100的出现次数为{}".format(list1.count(100)))
