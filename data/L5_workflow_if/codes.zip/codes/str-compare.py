#字符串的比较是按照顺序依次比较字母编码

#a 0x31；1 0x61
str1="abc"
str2="1234"
str3="abc1234"

if str1 > str2:
    print ("1")
else:
    print ("2")

if str1 > str3:
    print ("3")
else:
    print ("4")

input("按回车退出")
