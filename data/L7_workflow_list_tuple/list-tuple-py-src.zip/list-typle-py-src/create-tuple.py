#创建元组

#方法１使用()或tuple()创建空元组
tuple1 = ()
tuple2 = tuple()
print(tuple1)

#方法2 创建时指定元素, 元素间用逗号隔开
tuple3 = ('huawei', 'xman', 19.87, 2017)
print(tuple3)

#可不加括号
tuple4 = 'huawei', 'xman', 19.87, 2017
print(tuple4)

#注意：元组中可以包含list列表，元组中list列表的值时可变的；
tuple5 = ('huawei', 'xman', 19.87, [1,2,3,4])
print(tuple5)

tuple6 = ('xman')  # 无逗号
print(type(tuple6)) # tuple5是str类型

tuple6 = ('xman',)  # 当定义元组只有一个值时,要在后面加上逗号
print(type(tuple6))
