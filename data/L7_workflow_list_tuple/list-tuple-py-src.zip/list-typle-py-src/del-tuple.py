t = ('huawei', 'xman', 4.56, 2018)
# del(t[1]) 错误，不能对t中的元素增删改

del t #可删除整个元组
print(t)  # 元组已被删除，变量t无所指，抛出NameError异常
