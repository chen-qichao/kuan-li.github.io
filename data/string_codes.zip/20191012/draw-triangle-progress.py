import math
import time

tmpStr=input("请输入打印三角形的行数")
lines=int(tmpStr)
max_line_width=2*lines + 1


print('开始绘制')
start=time.perf_counter()
for i in range(0,lines):
    star_len= 2*i + 1
    line_str=star_len*"*"
    print('\r'+line_str.center(max_line_width))

    #以下用于更新进度条信息
    a=(i/lines)*100
    b=i*"*"
    c=(lines-i)*"."
    dur=time.perf_counter()-start

    print("\r{:^.0f}%[{}-->{}]{:.2f}s".format(a,b,c,dur), end="")
    time.sleep(0.5)


print('\r'+'绘制结束'.center(max_line_width))
