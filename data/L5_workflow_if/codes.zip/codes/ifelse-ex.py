# if else example

x=10
y=20

if x > y:
  print("x is bigger")
else :
  print("y is bigger")

