#list-expression.py, 列表推导式

multiples = [i for i in range(30) if i % 3 is 0]
print(multiples)

squared1 = []
for x in range(10):
    squared1.append(x**2) #依次添加到列表中
print(squared1)

squared2 = [x**2 for x in range(10)]#和上面依次添加等价
print(squared2)
