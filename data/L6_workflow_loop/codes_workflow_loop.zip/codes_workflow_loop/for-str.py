#从字符串中依次取一个字符,放入循环变量c中

#c: 字符串,在Python中,单个字符也是字符串
for c in "hello,world":
    print(c)
