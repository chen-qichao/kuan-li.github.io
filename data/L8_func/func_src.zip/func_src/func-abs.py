#func-abs.py
#对比内置函数abs和自定义函数my_abs
def my_abs(x):
    if x >= 0:
        return x
    else:
        return -x

print("my_abs(-2) is ", my_abs(-2))
print("abs(-2) is ", abs(-2))
