#字典存储电话号码
contacts = {"赵云":"133 0928 3335",
            "乔丹":"188 0731 7878",
            "C 罗":"150 9348 8129",
            "韦德":"192 8293 7665"}

name = input("输入姓名：")

if name in contacts:   #in默认是检查键(key)是否在字典中
    print(name, ":", contacts[name])
else:
    print("未找到" + name)
