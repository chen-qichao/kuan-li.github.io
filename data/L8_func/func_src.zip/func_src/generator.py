#generator.py 生成器惰性求值

range_ = (x ** 3 for x in range(5))

print(range_)#惰性求值
print(range_.__next__())#惰性求值，调用__next__函数才触发
print(range_.__next__())
print(range_.__next__())

print("for能触发__next__") 
#for循环可触发__next__
for n in (x ** 3 for x in range(5)):
    print(n)
