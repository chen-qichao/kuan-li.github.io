#depack-dict.py 字典解包
dict1 = {'a':1,'b':2,'c':3,'d':4}
a,*b,c = dict1 #默认情况下，解包的是字典键值
print(a,b,c)
a,*b,c = dict1.values()#values()函数，解包的是值
print(a,b,c)
a,*b,c = dict1.items()#键值对
print(a,b,c)
