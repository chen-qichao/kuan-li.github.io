#generator-once.py 生成器只能执行１次

range_ = (x ** 3 for x in range(5))
ls1 = list(range_)
print(ls1)
ls2 = list(range_) #再次执行时，ls2为空
print(ls2)
