#func.py　将求圆面积公式抽象为函数
import math

#定义函数circle_area
def circle_area(r):
    s = math.pi * r * r#面积公式s=pi * r^2
    return s

r1 = 12.34
r2 = 9.08
r3 = 73.1

s1 = circle_area(r1) #调用circle_area函数即可，参数是半径
s2 = circle_area(r2)
s3 = circle_area(r3)

print("s1 is {:.2f}, s2 is {:.2f}, s3 is {:.2f}".format(s1,s2,s3))
