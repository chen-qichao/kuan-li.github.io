t = ('huawei', 'xman', 4.56, 2018)
l = list(t)
l[1] = "莞工"
print("tuple: ", t)
print("list: ", l)

l1=tuple(l)
print(l1)
