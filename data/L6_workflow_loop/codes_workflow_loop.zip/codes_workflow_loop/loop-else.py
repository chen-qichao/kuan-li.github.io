#循环结构中的else示例
x = int(input("请输入1个整数: ")) #接受用户键盘输入

while x <= 10: #条件循环
    print (x)
    x = x+1
    '''只有当x等于7这个条件不满足,break不执行时,
    才会执行第12行else部分'''
    if x == 7: #如果x等于7，执行break, 跳出循环
        break; 
else:
    print("执行else部分")

print("循环执行完毕")
