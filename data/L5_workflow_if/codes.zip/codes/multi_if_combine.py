#python条件组合

mark = int(input("请输入取得的分数: "))

if not mark < 60:
    #下句中的60 <= mark 可省略
    if 60 <= mark and mark < 70:
        print ("You got C Grade !!")
    elif 70 <= mark and mark < 85:
        print ("You got B Grade !!")
    else:
        print ("You got A Grade !!")
else:
    print ("You failed !!")

input("按回车退出")
