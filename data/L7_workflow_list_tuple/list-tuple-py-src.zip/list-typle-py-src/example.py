#定义列表或元组
#numbers = ['零', '一', '二', '三', '四', '五', '六', '七', '八', '九']
numbers = ('零', '一', '二', '三', '四', '五', '六', '七', '八', '九')

str_in = input("请输入一个数字:") #接受用户输入，存入字符串str_in

#num_in = int (str_in) #将字符串str_in转换为整数num_in

str_out=""
for s in str_in:  #遍历输入字符串
    n = int (s) #将字符转换为数字
    if n in range(len(numbers)): #如果n在numbers长度范围内
        str_out = str_out + numbers[n] #下标索引，+拼接

print(str_out)
