#创建列表

#方法１使用[]或list()创建空列表，然后调用列表的方法为列表添加元素
list1 = []
list2 = list()

#方法2 创建时指定元素, 元素间用逗号隔开
list3 = ['huawei', 'xman', 19.87, 2017]
print(list3)

#备注:列表中可以嵌套列表，字典，元组等
list4 = [2018, 'A', True, list3]
print(list4)
