#集合去重
import random #导入random库

list1 = [] #建立空列表

while True:
    num = random.randint(1,100) #在[1,100]之间取随机整数
    for e in list1: #对列表来说,需要先判断num是否存在
        if e == num: #如果相等,说明已存在
            break;
    else: #不被break跳出时执行
        list1.append(num)

    if len(list1) >= 10: #取够10个退出
        break

print(list1)
