l = ['huawei', 'xman', 4.56, 2018]
print('原列表', l)

del l[0:2]  # 删除列表第一到第二个元素
print('删除前两个元素后的列表', l)

del l  # 删除整个列表,其他类型的变量亦可通过del删除
print(l)  # 列表无法访问，抛出NameError，提示无l这个变量
