# tuple元组元素不可以修改
# 但可同过元组相加创建一个新元组

t1 = ('huawei', 'xman')
t2 = (1, 2, 3, '莞工')

t3 = t1 + t2
print(t3)

t4 = t1 * 4
print(t4)
