#集合间的交并差补操作
s={1,2,3}

s.add(4) #增加1个新的元素
print(s)

s.update({3,4,5}) #等价于s |= {3,4,5}
print(s)

s.discard(5) # 移除元素5,如果没有,不报错
print(s)

s.remove(5) # 移除元素5,如果没有,报错KeyError
