#break跳出while循环范例
n = 1 #给变量n赋初值1
while True: #无限循环
    print (n)
    n += 1 #等价于n=n+1
    if n== 5: #条件判断，如果n等于5，执行break，跳出循环
        break

print("while循环执行完毕")

#break跳出for循环范例
for s in "Python": #遍历字符串Python，将每个字符放入循环变量s
    if s == "t": #条件判断，如果字符(串)是"t", 执行break，跳出循环
        break
    print(s)

print("for循环执行完毕")
