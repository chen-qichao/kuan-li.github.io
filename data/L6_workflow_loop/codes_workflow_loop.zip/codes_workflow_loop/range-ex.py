#[range-ex.py] range函数: range(start,stop,step)

print("range(3)输出:")
for n in range(3): #只有一个参数时,默认start=0, step=1
    print(n)

print("range(5,10)输出:")
for n in range(5,10): #两个参数,给定start,stop,范围:[start,stop), step=1
    print(n)

print("range(0,10,2)输出:")
for n in range(0,10,2): #三个参数,分表表示start,stop,step
    print(n)
