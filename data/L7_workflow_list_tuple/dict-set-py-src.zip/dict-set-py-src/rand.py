import random #导入random库

#直接调用random库的sample函数
#两个参数: 1st 序列或集合 2nd 个数
#意义: 从某序列或集合中取若干个不重复的值
l = random.sample(range(1,101),10)
print(l)
