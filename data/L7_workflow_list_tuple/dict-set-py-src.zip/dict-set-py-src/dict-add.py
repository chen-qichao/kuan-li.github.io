#字典中元素的增删改

#访问字典中的元素
aDict = {'age':39, 'score': [98,97], 
        'name': 'Dong','sex':'male'}

aDict['age']=40 #对应键值存在时，修改元素的值
aDict['address']="莞工" #对应键值不存在时，添加新元素
print(aDict)

bDict = {"age":38, 7:"xyz"} #定义另外1个字典
#将另一个字典的所有的键值对一次性全部添加到当前字典对象中
aDict.update(bDict)
print(aDict)

x = aDict.setdefault("age",36)
print(x)
print(aDict)
