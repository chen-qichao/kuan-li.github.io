#字典遍历

aDict = {'age':39, 'score': [98,97], 
        'name': 'Dong','sex':'male'}

for item in aDict:   #遍历的是键
    print(item, end=" : ")
    print(aDict[item], end=" , ")
print()

#下列用法与上面等价
for item in aDict.keys():   #遍历的是键
    print(item, end=" : ")
    print(aDict[item], end=" , ")
print()
