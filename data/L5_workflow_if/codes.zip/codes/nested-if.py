#python分支嵌套

mark = int(input("请输入取得的分数: "))

if mark >= 60:
    if mark >= 85:
        print ("You got A Grade !!")
    elif mark >= 70:
        print ("You got B Grade !!")
    else:
        print ("You got C Grade !!")
else:
    print ("You failed !!")

input("按回车退出")
