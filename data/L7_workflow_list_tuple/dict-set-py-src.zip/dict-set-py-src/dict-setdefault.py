#字典中setdefault用法

aDict = {'age':39, 'score': [98,97],
        'name': 'Dong','sex':'male'}

#在键值"age"存在的情况下，设置的36不起作用
x = aDict.setdefault("age",36)
print(x) #打印返回值
print(aDict) #打印字典

#不存在对应的键值，新增元素
y = aDict.setdefault("nationality","China") 
print(y) #打印返回值
print(aDict) #打印字典
