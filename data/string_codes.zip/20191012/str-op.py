#转义符

tmpStr1="abcd"
tmpStr2="123456"

print(tmpStr1 + tmpStr2)
print(tmpStr1 + "5678")
print("xyz" + "5678")

print(3*tmpStr1)
print(tmpStr2*2)
#print(tmpStr2*2.0)  #ERROR

if "ab" in tmpStr1:
    print("1.YES!")
else:
    print("1.NO!")

if "ab" in tmpStr2:
    print("2.YES!")
else:
    print("2.NO!")
