#var.py, 变量是到对象的引用

a = 3
print("a: id = {}, type = {}, value = {}".format(id(a),type(a),a) )
print("3: id = {}, type = {}, value = {}".format(id(3),type(3),3) )

b = a #多个变量都引用了相同的对象，成为共享引用
print("b: id = {}, type = {}, value = {}".format(id(b),type(b),b) )

print("修改后")
# 对变量a修改，因为数字是不可修改类型
# 等价于重新"建立"对象2，然后将a指向它
a = 2
print("a: id = {}, type = {}, value = {}".format(id(a),type(a),a) )
print("2: id = {}, type = {}, value = {}".format(id(2),type(2),2) )
print("b: id = {}, type = {}, value = {}".format(id(b),type(b),b) )
