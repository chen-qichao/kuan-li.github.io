#in and not in

color = ['Red','Blue','Green']

selColor = "Red"
if selColor in color:
  print("Red is in the list")
else:
  print("Red is not in the list")

if "Yellow" not in color:
  print("Yellow is not in the list")
else:
  print("Yellow is in the list")
