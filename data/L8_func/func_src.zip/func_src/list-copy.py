#list-copy, 列表类型共享引用

a = [1, 2, 3]
b = a[:] # 单独创建了新的对象，并拷贝列表中的元素到新对象中
print("id(a) is", id(a), "id(b) is", id(b))

a[0] = 0 #修改ａ引用对象的内部元素
print(a, "id(a) is", id(a))
#b引用的对象并未发生变化，故b的值不变
print(b, "id(b) is", id(b))
