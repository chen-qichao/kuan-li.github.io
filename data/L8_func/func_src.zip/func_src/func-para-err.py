#func-para-err.py，演示参数个数有误的情况
#对比abs和自定义my_abs

def my_abs(x):
    if x >= 0:
        return x
    else:
        return -x

#Python解释器会报错
print("my_abs(-2) is ", my_abs(-2,-3))
