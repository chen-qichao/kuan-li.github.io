#遍历循环示例

#n为循环变量,range(7)返回[0,1,2,3,4,5,6]
for n in range(7):
      print(n) #循环中的语句块
