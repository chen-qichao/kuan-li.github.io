#list-deep-copy.py 深拷贝　
import copy

a = [1, [4, 5, 6]]
b = copy.deepcopy(a)

#深拷贝，a和b指向不同对象，
#其中的元素(尤其是二级列表)也指向相同的对象
print("id(a) is", id(a), "id(b) is", id(b))
print("id(a[0]) is", id(a[0]), "id(b[0]) is", id(b[0]))
print("id(a[1]) is", id(a[1]), "id(b[1]) is", id(b[1]))
