#打印九九乘法表范例

print("打印下三角")
for i in range(1, 10): #循环变量i取[1,10)
    for j in range(1, i+1): #循环变量j取[1,i+1)
        #打印,不换行, 注意{:2d}的意义
        print("{}*{}={:2d}".format(i,j,i*j),end="    ")
    print("") #只有i的值更换时才换行

print("打印上三角")
for i in range(1, 10): #循环变量i取[1,10)
    for j in range(1, i): #循环变量j取[1,i)
        print("      ",end="    ") # 打印前面的空格, 不换行
    for j in range(i, 10):#循环变量j取[i,10), 打印真正有效信息
        print("{}*{}={:2d}".format(i,j,i*j),end="    ")
    print("") #只有i的值更换时才换行
