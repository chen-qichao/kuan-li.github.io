#创建集合

#方法１使用set()建立空集合
empty_set1=set()

#方法2 创建时指定元素, 元素间用逗号隔开
set2 = {'huawei', 'xman', 19.87, 2017}
print(set2)

set3=set("12345") #set()函数将字符串转化为集合
set4=set([1,2,3,4,5]) #set()函数将列表转化为集合
set5=set((1,2,3,4,5)) #set()函数将元组转化为集合

print(set3)
print(set4)
print(set5)
