#func-para-type.py 演示参数类型错误的情况
#对比abs和自定义my_abs

def my_abs(x):
    #参数类型错误必须自己判断处理
    if not isinstance(x, (int, float)):
	#抛出异常
        raise TypeError('自定义:my_abs要求输入int或float类型')
    if x >= 0:
        return x
    else:
        return -x

print("my_abs(\"A\") is ", my_abs("A"))
