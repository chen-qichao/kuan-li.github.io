#if example

x=20
y=0

if x > y :
  print("x is bigger 1st")
  print("x is bigger 2nd")
  print("x is bigger 3rd")

if x:
  print("non-zero equals true")
