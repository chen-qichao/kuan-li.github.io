#访问字典中的元素

#创建字典aDict
aDict = {'age':39, 'score': [98,97],
        'name': 'Dong','sex':'male'}

print(aDict['age'])  #指定的"键"存在，返回对应的"值"
#指定的"键"不存在，抛出KeyError异常
#print(aDict['address'])

#如果字典中存在该"键"则返回对应的"值"
print(aDict.get('age'))
#如果字典中不存在"键"则返回指定的默认值
print(aDict.get('address','莞工'))
