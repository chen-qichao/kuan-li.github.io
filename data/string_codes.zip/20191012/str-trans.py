#转义符
print('1. 这里有个单引号\' ')
print("2. 这里有个单引号\" ")
print("3. 这里有个斜线\\ ")

print("4. abcd\\be")
print("5. abcd\be")
print("6. abcd\b\b\be")

print("7.abcdefghijk\r1234")
print("8. abcdefghijk\n1234")
