l = ['huawei', 'xman', 4.56, 2018]
print("原列表为",l)

l1 = [7, 8, 9]
l.extend(l1)  # 在列表末尾一次性追加另一序列中的多个值(用新列表扩展原来的列表）
print(l)

l.reverse()  # 反向列表中元素
print(l)

l2 = l.copy()  # 复制列表
print(l2)

l.clear()  # 清空列表
print(l)

l3 = [3, 4, 2, 9, 4]
l3.sort()  # 对原列表进行排序,前提是可排序, 字符串和数字无法比较
print(l3)
