#集合去重
import random

set1 = set()  #建立空集合

while True:
    num = random.randint(1,100) #返回[1,100]之间的随机数
    set1.add(num) #直接添加,自动过滤重复值
    if len(set1) >= 10: #随机数个数满足要求时,退出循环
        break

print(set1)
