#id-type-value.py, 对象的三个特征：身份，类型和值

n1 = 1#整数类型
str1 = "hello"#字符串类型
#依次输出身份，类型和值
print ( "n1, id = {}, type = {}, value = {}"
        .format(id(n1), type(n1), n1))
print ( "str1, id = {}, type = {}, value = {}"
        .format(id(str1), type(str1), str1))
