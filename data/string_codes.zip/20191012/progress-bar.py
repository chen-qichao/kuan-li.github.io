import math
import time

tmpStr=input("请输入进度分割数")
lines=int(tmpStr)

print("开始执行")
start=time.perf_counter()
for i in range(0,lines):

    #以下用于更新进度条信息
    a=(i/lines)*100
    b=i*"*"
    c=(lines-i)*"."
    dur=time.perf_counter()-start

    print("\r{:^.0f}%[{}-->{}]{:.2f}s".format(a,b,c,dur), end="")

    time.sleep(0.5)

print("\n执行结束")
