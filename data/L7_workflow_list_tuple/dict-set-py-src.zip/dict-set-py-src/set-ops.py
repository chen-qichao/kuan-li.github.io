#集合间的交并差补操作
fib=set((1,1,2,3,5,8,13))
prime=set((2,3,5,7,11,13))

print( fib | prime ) #并
print(fib.union(prime)) #并

print( fib & prime ) #交
print(fib.intersection(prime)) #交

print( fib - prime ) #差
print(fib.difference(prime)) #差

print( fib ^ prime ) #补
print(fib.symmetric_difference(prime)) #补
